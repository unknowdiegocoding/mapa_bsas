ciudades-argentinas
===================

Scraper de ciudades argentinas basado en los datos publicados en http://www.migraciones.gov.ar/

Modo de uso
-----------

1. bundle install

2. chmod +x scraper.rb

3. ./scraper.rb
